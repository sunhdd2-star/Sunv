package com.hauntedsoul.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

public class HauntedSoulClient implements ClientModInitializer {
	public static final String MOD_ID = "hauntedsoul";
	static final Random RNG = new Random();

	private record Task(long at, Runnable run) {}

	private static final List<Task> TASKS = new ArrayList<>();
	private static long now = 0;
	private static int cooldown = 1800;
	private static int minuteTicks = 0;
	private static boolean wasInWorld = false;

	@Override
	public void onInitializeClient() {
		Story.load();

		HudElementRegistry.attachElementAfter(
			VanillaHudElements.SUBTITLES,
			Identifier.fromNamespaceAndPath(MOD_ID, "haunt_overlay"),
			Jumpscare::render
		);

		ClientTickEvents.END_CLIENT_TICK.register(HauntedSoulClient::onTick);

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
			dispatcher.register(ClientCommandManager.literal("diary").executes(ctx -> {
				Story.printDiary(ctx.getSource());
				return 1;
			}));
			dispatcher.register(ClientCommandManager.literal("ghost")
				.then(ClientCommandManager.literal("diary").executes(ctx -> {
					Story.printDiary(ctx.getSource());
					return 1;
				}))
				.then(ClientCommandManager.literal("scare").executes(ctx -> {
					Jumpscare.start();
					return 1;
				}))
				.then(ClientCommandManager.literal("whisper").executes(ctx -> {
					whisper(ctx.getSource().getClient());
					return 1;
				}))
				.then(ClientCommandManager.literal("next").executes(ctx -> {
					Story.unlockNext(ctx.getSource().getClient());
					return 1;
				}))
				.then(ClientCommandManager.literal("reset").executes(ctx -> {
					Story.reset();
					ctx.getSource().sendFeedback(Component.literal("\u00a78Reset."));
					return 1;
				})));
		});
	}

	// ---------- sound helpers ----------

	/** SoundEvents constants can be either SoundEvent or Holder<SoundEvent>; these overloads accept both. */
	static SoundEvent s(SoundEvent e) {
		return e;
	}

	static SoundEvent s(Holder<SoundEvent> h) {
		return h.value();
	}

	/** Plays a sound directly in the player's head. */
	static void ui(Minecraft mc, SoundEvent event, float pitch, float volume) {
		mc.getSoundManager().play(SimpleSoundInstance.forUI(event, pitch, volume));
	}

	/** Plays a sound at a spot around the player. angleDeg 180 = directly behind. */
	static void around(Minecraft mc, SoundEvent event, double dist, double angleDeg, float volume, float pitch) {
		if (mc.player == null || mc.level == null) return;
		double yaw = Math.toRadians(mc.player.getYRot() + angleDeg);
		double x = mc.player.getX() - Math.sin(yaw) * dist;
		double z = mc.player.getZ() + Math.cos(yaw) * dist;
		mc.level.playLocalSound(x, mc.player.getY(), z, event, SoundSource.AMBIENT, volume, pitch, false);
	}

	private static void schedule(int delayTicks, Runnable r) {
		TASKS.add(new Task(now + delayTicks, r));
	}

	// ---------- main loop ----------

	private static void onTick(Minecraft mc) {
		Jumpscare.tick();

		if (mc.player == null || mc.level == null) {
			TASKS.clear();
			wasInWorld = false;
			return;
		}
		if (!wasInWorld) {
			wasInWorld = true;
			cooldown = 1200 + RNG.nextInt(1200);
		}
		now++;

		List<Task> due = new ArrayList<>();
		for (Task t : TASKS) {
			if (t.at() <= now) due.add(t);
		}
		TASKS.removeAll(due);
		for (Task t : due) t.run().run();

		if (mc.screen != null) return;

		if (++minuteTicks >= 1200) {
			minuteTicks = 0;
			Story.addMinute(mc);
		}

		int chapter = Story.chapter();
		boolean zone = mc.player.getY() < 50 || !mc.level.canSeeSky(mc.player.blockPosition()) || chapter >= 4;

		if (cooldown > 0) {
			cooldown--;
			return;
		}
		if (!zone || Jumpscare.active()) return;

		triggerRandomEvent(mc, chapter);
		int base = Math.max(600, 3000 - chapter * 330);
		cooldown = base / 2 + RNG.nextInt(base);
	}

	private static void triggerRandomEvent(Minecraft mc, int chapter) {
		int roll = RNG.nextInt(100);
		if (chapter >= 2 && roll < 10 + chapter * 4) {
			buildUpThenScare(mc);
		} else if (chapter >= 3 && roll < 30) {
			curse(mc);
		} else if (chapter >= 2 && roll < 48) {
			heartbeat(mc, 4);
		} else if (chapter >= 1 && roll < 66) {
			footsteps(mc);
		} else if (chapter >= 1 && roll < 80) {
			Jumpscare.flicker(40);
			ui(mc, s(SoundEvents.AMBIENT_CAVE), 0.6f, 0.9f);
		} else if (chapter >= 2 && roll < 90) {
			around(mc, s(SoundEvents.WOODEN_DOOR_CLOSE), 4 + RNG.nextInt(6), RNG.nextInt(360), 1.0f, 0.7f);
		} else {
			whisper(mc);
		}
	}

	// ---------- events ----------

	static void whisper(Minecraft mc) {
		if (mc.player == null) return;
		mc.player.displayClientMessage(Component.literal("\u00a78<\u00a74มะลิ\u00a78> \u00a77\u00a7o" + Story.randomWhisper()), false);
		ui(mc, s(SoundEvents.AMBIENT_CAVE), 0.7f, 0.8f);
	}

	private static void heartbeat(Minecraft mc, int beats) {
		for (int i = 0; i < beats; i++) {
			schedule(i * 16, () -> ui(mc, s(SoundEvents.WARDEN_HEARTBEAT), 1.0f, 1.0f));
		}
	}

	private static void footsteps(Minecraft mc) {
		for (int i = 0; i < 7; i++) {
			final double dist = 9 - i;
			schedule(i * 12, () -> around(mc, s(SoundEvents.ZOMBIE_STEP), dist, 180, 1.0f, 0.6f));
		}
		schedule(7 * 12 + 10, () -> whisper(mc));
	}

	private static void curse(Minecraft mc) {
		ui(mc, s(SoundEvents.ELDER_GUARDIAN_CURSE), 0.7f, 0.8f);
		Jumpscare.flicker(30);
		schedule(25, () -> whisper(mc));
	}

	private static void buildUpThenScare(Minecraft mc) {
		whisper(mc);
		heartbeat(mc, 6);
		schedule(40, () -> Jumpscare.flicker(25));
		schedule(100, Jumpscare::start);
	}
}
