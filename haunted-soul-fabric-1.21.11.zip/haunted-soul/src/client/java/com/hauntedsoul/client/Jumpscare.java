package com.hauntedsoul.client;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

/** Full-screen jumpscare + screen flicker, drawn on the HUD with plain rectangles (no textures needed). */
final class Jumpscare {
	private static final int DURATION = 46;
	private static final int FADE = 12;

	private static int t = -1; // -1 = not running
	private static int flicker = 0;

	private Jumpscare() {}

	static boolean active() {
		return t >= 0;
	}

	static void flicker(int ticks) {
		flicker = ticks;
	}

	static void start() {
		Minecraft mc = Minecraft.getInstance();
		t = 0;
		HauntedSoulClient.ui(mc, HauntedSoulClient.s(SoundEvents.GHAST_SCREAM), 0.5f, 1.0f);
		HauntedSoulClient.ui(mc, HauntedSoulClient.s(SoundEvents.ELDER_GUARDIAN_CURSE), 0.6f, 1.0f);
		HauntedSoulClient.ui(mc, HauntedSoulClient.s(SoundEvents.ENDERMAN_STARE), 0.5f, 1.0f);
	}

	static void tick() {
		if (t >= 0) {
			t++;
			if (t > DURATION + FADE) t = -1;
		}
		if (flicker > 0) flicker--;
	}

	static void render(GuiGraphics g, DeltaTracker tracker) {
		int w = g.guiWidth();
		int h = g.guiHeight();

		if (t < 0) {
			if (flicker > 0 && ((flicker / 3) % 2 == 0 || HauntedSoulClient.RNG.nextInt(6) == 0)) {
				g.fill(0, 0, w, h, 0xF0000000);
			}
			return;
		}

		if (t < 3) { // white flash
			g.fill(0, 0, w, h, 0xFFFFFFFF);
			return;
		}

		if (t <= DURATION) {
			g.fill(0, 0, w, h, 0xFF000000);
			double prog = t / (double) DURATION;
			double cell = h * (0.92 + 0.38 * prog) / FaceData.H;
			int fw = (int) (FaceData.W * cell);
			int fh = (int) (FaceData.H * cell);
			int shake = (int) (cell * (t < 30 ? 1.6 : 0.6));
			int ox = (w - fw) / 2 + (shake > 0 ? HauntedSoulClient.RNG.nextInt(shake * 2 + 1) - shake : 0);
			int oy = (h - fh) / 2 + (shake > 0 ? HauntedSoulClient.RNG.nextInt(shake * 2 + 1) - shake : 0);
			drawFace(g, ox, oy, cell);
			g.fill(0, 0, w, h, (t % 4 < 2) ? 0x40FF0000 : 0x28800000); // red tint
		} else { // sudden cut to black, then fade out
			int a = 255 - (t - DURATION) * 255 / FADE;
			if (a < 0) a = 0;
			if (a > 255) a = 255;
			g.fill(0, 0, w, h, a << 24);
		}
	}

	private static void drawFace(GuiGraphics g, int ox, int oy, double cell) {
		for (int y = 0; y < FaceData.H; y++) {
			String row = FaceData.ROWS[y];
			int x = 0;
			while (x < FaceData.W) {
				char c = row.charAt(x);
				if (c == '.') {
					x++;
					continue;
				}
				int x0 = x;
				while (x < FaceData.W && row.charAt(x) == c) x++;
				g.fill(
					ox + (int) Math.round(x0 * cell),
					oy + (int) Math.round(y * cell),
					ox + (int) Math.round(x * cell),
					oy + (int) Math.round((y + 1) * cell),
					color(c)
				);
			}
		}
	}

	private static int color(char c) {
		return switch (c) {
			case 'K' -> 0xFF050505; // black (hair, sockets, mouth)
			case 'W' -> 0xFFD9D4C7; // pale skin
			case 'w' -> 0xFFEDE8DC; // highlight
			case 'G' -> 0xFF8F8B80; // shade
			case 'g' -> 0xFF5E5B55; // dark shade
			case 'R' -> 0xFFD40000; // blood / glowing pupils
			case 'D' -> 0xFF6E0000; // dried blood
			case 'B' -> 0xFFE8E2B8; // teeth
			case 'Y' -> 0xFFA89F6A; // teeth tips
			default -> 0xFF000000;
		};
	}
}
