package com.hauntedsoul.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.loader.api.FabricLoader;

/** The story of Mali + progress saving. Progress = minutes played (saved in config). */
final class Story {
	/** Minutes of play needed to unlock each diary page. */
	static final int[] UNLOCK_MIN = {2, 8, 16, 28, 42, 60, 80};

	static final String[] PAGES = {
		"วันนี้พ่อพาฉันย้ายมาอยู่หมู่บ้านโพธิ์ดำ ชาวบ้านมองฉันแปลกๆ ยายข้างบ้านจับมือฉันแน่น แล้วกระซิบว่า \"อย่าออกจากบ้านหลังตะวันตกดินนะหนู\"",
		"ทุกคืนฉันได้ยินเสียงเด็กร้องไห้ใต้ต้นโพธิ์ใหญ่กลางหมู่บ้าน พอแอบไปดูก็ไม่มีใคร มีแต่รอยเท้าเล็กๆ เปียกๆ เดินเข้ามาหาบ้านของฉัน",
		"พวกผู้ใหญ่ประชุมกันลับๆ ฉันแอบได้ยินคำว่า \"พิธีเซ่นต้นโพธิ์\" และชื่อของฉัน... ทำไมต้องเป็นฉัน",
		"พ่อไม่ยอมมองหน้าฉัน เขาล็อกประตูห้องจากข้างนอก คืนนี้มีเสียงกระซิบดังมาจากใต้เตียง มันบอกว่า \"หนีไป... ก่อนมันจะมาเอาเธอ\"",
		"ฉันหนีออกมาได้ แต่ทุกทางออกจากหมู่บ้านวนกลับมาที่ต้นโพธิ์เสมอ ทุกบ้านมืดสนิท และฉันรู้สึกว่ามีสายตานับร้อยคู่จ้องมองอยู่ในความมืด",
		"พวกเขาจับฉันได้ ฉันถูกฝังไว้ใต้ต้นโพธิ์ทั้งที่ยังหายใจอยู่ ดินมันหนัก มืด และหนาวมาก ฉันร้องเรียกพ่อ... เขายืนมองอยู่เฉยๆ",
		"ตอนนี้ฉันไม่หนาวแล้ว... ฉันเห็นเธอแล้ว เธอที่กำลังอ่านอยู่นี่แหละ ฉันรอเธอมานานเหลือเกิน อยู่เป็นเพื่อนมะลินะ... ตลอดไป"
	};

	private static final String[] WHISPERS_EARLY = {
		"มะลิหนาว...",
		"ใครอยู่ตรงนั้น...",
		"ได้ยินไหม... เสียงร้องไห้",
		"อย่าออกไปข้างนอกนะ...",
		"ฉันเห็นเธอนะ..."
	};
	private static final String[] WHISPERS_MID = {
		"อยู่ข้างหลังเธอ...",
		"อย่าหันกลับไป",
		"ดินมันหนัก... ช่วยฉันด้วย",
		"ทำไมไม่ตอบมะลิ...",
		"เล่นด้วยกันนะ"
	};
	private static final String[] WHISPERS_LATE = {
		"เธอหนีไม่พ้นหรอก...",
		"มะลิอยู่ใกล้ๆ แล้วนะ",
		"มองมาที่ฉันสิ...",
		"อยู่กับฉันตลอดไป",
		"มาอยู่ใต้ต้นโพธิ์ด้วยกัน"
	};

	private static int minutes = 0;

	private Story() {}

	static int chapter() {
		int c = 0;
		for (int m : UNLOCK_MIN) {
			if (minutes >= m) c++;
		}
		return c;
	}

	static String randomWhisper() {
		int c = chapter();
		java.util.Random r = HauntedSoulClient.RNG;
		if (c >= 5) return WHISPERS_LATE[r.nextInt(WHISPERS_LATE.length)];
		if (c >= 2) return WHISPERS_MID[r.nextInt(WHISPERS_MID.length)];
		return WHISPERS_EARLY[r.nextInt(WHISPERS_EARLY.length)];
	}

	static void addMinute(Minecraft mc) {
		int before = chapter();
		minutes++;
		save();
		if (chapter() > before) announce(mc);
	}

	static void unlockNext(Minecraft mc) {
		for (int m : UNLOCK_MIN) {
			if (m > minutes) {
				minutes = m;
				save();
				announce(mc);
				return;
			}
		}
	}

	static void reset() {
		minutes = 0;
		save();
	}

	private static void announce(Minecraft mc) {
		if (mc.player == null) return;
		mc.player.displayClientMessage(Component.literal("\u00a78[\u00a74!\u00a78] \u00a77พบหน้าไดอารี่ใหม่ของมะลิ... พิมพ์ \u00a7c/diary \u00a77เพื่ออ่าน"), false);
		HauntedSoulClient.ui(mc, HauntedSoulClient.s(SoundEvents.AMBIENT_CAVE), 0.7f, 0.9f);
	}

	static void printDiary(FabricClientCommandSource src) {
		int c = chapter();
		if (c == 0) {
			src.sendFeedback(Component.literal("\u00a78ยังไม่พบหน้าไดอารี่... อยู่ในโลกต่อไปก่อน"));
			return;
		}
		src.sendFeedback(Component.literal("\u00a74\u00a7l=== ไดอารี่ของมะลิ ==="));
		for (int i = 0; i < c && i < PAGES.length; i++) {
			src.sendFeedback(Component.literal("\u00a78หน้า " + (i + 1) + ": \u00a77\u00a7o" + PAGES[i]));
		}
		if (c < PAGES.length) {
			src.sendFeedback(Component.literal("\u00a78... ยังมีหน้าที่ถูกฉีกออกไป (" + (PAGES.length - c) + " หน้า)"));
		}
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("haunted_soul.properties");
	}

	static void load() {
		Path f = file();
		if (!Files.exists(f)) return;
		try (InputStream in = Files.newInputStream(f)) {
			Properties p = new Properties();
			p.load(in);
			minutes = Integer.parseInt(p.getProperty("minutes", "0").trim());
		} catch (IOException | NumberFormatException e) {
			minutes = 0;
		}
	}

	private static void save() {
		try (OutputStream out = Files.newOutputStream(file())) {
			Properties p = new Properties();
			p.setProperty("minutes", Integer.toString(minutes));
			p.store(out, "Haunted Soul progress");
		} catch (IOException ignored) {
			// progress just won't be saved
		}
	}
}
